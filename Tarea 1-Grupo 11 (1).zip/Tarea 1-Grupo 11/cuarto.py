L=[]
for x in range (3):
    numeros=int(input("Ingrese numero: "))
    L.append(numeros)
    print(L)
L.reverse()
print(L)